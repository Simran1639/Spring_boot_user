package com.company.springboot.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootUserExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootUserExampleApplication.class, args);
	}

}
